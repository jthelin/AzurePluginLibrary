Import-Module Servermanager
Add-WindowsFeature SMTP-Server